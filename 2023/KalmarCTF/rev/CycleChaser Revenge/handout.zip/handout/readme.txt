This challenge is relatively resource intensive, so we have a proof of work on the remote. 
We advise to develop your exploit locally first!