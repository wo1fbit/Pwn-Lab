We supply qemu for complete consistency with server, but you'll probably do fine with your own.

A JS engine in x86 real mode:
> a=1+1
> b=2+2
> l(a+b)
0006
Good luck.
